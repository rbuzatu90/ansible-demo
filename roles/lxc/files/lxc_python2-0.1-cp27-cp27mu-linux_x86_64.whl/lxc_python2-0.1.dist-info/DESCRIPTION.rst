The lxc-python2 package contains lxc bindings for python2


